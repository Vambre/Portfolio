# Titre de la Merge Request

## Tâches/Issues associées

Liste des tâches/issues associés à cette Merge Request :

* #1
* #2

## Principaux changements

Cette Merge Request apporte les modifications/ajouts/suppressions suivants au projet :

* Changement 1
* Changement 2

## Remarques et commentaires

Ajouter ici des eventuels remarques ou commentaires au sujet de votre Merge Request
