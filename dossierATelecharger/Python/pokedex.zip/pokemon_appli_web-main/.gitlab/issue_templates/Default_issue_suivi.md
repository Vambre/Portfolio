# Titre de la tâche  
  
Suivi de projet avec le tuteur  

## Objectifs généraux  

Les objectifs de la tâche de suivi sont :  
  
- Faire le bilan de ce qui a été effectué
- Si possible, faire une démonstration du livrable de fin de sprint et obtenir le feedback du PO
- Définir les objectifs du sprint à venir

## Informations  

Toutes informations pertinentes pour faciliter la réalisation de la tâche/issue (ex.: répartition des tâches sur les membres)

## Description détaillée  

Description détaillée, par membre, si besoin
