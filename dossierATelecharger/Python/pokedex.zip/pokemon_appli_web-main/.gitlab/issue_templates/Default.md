# Titre de la tâche/issue

## Objectifs

Courte description des objectifs de la tâche/issue

## Informations

Toutes informations pertinentes pour faciliter la réalisation de la tâche/issue

## Description détaillée

Description détaillée, spécifications, expression du besoin
