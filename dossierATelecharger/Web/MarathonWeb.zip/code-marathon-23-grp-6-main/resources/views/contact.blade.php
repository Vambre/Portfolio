@extends("templates.app")

@section('css')
  
@append

@section('content')
    <div style="display: flex;align-items: center; justify-content: center">
        <div>
            <b>Contact me</b>
        </div>
    </div>

@endsection