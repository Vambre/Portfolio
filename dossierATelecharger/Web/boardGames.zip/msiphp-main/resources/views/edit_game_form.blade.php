<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @vite(['resources/css/header.css', 'resources/css/footer.css'])
    <title>Modifier le jeu</title>
</head>
<body class="font-sans bg-[url('../images/fondTest.jpg')] bg-center bg-cover bg-no-repeat bg-fixed">
<x-header></x-header>
<div class="h-[60%] w-[50%] text-black bg-white rounded-2xl p-4 mt-[40px] ml-[25%]">
<h1 class="text-4xl text-center font-bold mb-[20px]">Modifier le jeu</h1>

    <div class="flex ml-[25%}">
<form  class="flex flex-col ml-[35%] gap-4" action="{{ route('updateGame', ['id' => $game['id']]) }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('POST')
<div><label for="name">Nom du jeu:</label>
    <input class="form-input bg-gray-200" type="text" name="name" value="{{ $game['name'] }}" required>
    <br></div>

<div><label for="description">Description:</label>
    <textarea class="form-input bg-gray-200" name="description" required>{{ $game['description'] }}</textarea>
    <br></div>

<div><label for="price">Prix:</label>
    <input class="form-input bg-gray-200" type="number" name="price" value="{{ $game['price'] }}" required>
    <br></div>

<div><label for="number_gamer">Nombre de joueurs:</label>
    <input class="form-input bg-gray-200" type="number" name="number_gamer" value="{{ $game['number_gamer'] }}" required>
    <br></div>

<div><label for="playing_time">Temps de jeu:</label>
    <input class="form-input bg-gray-200" type="text" name="playing_time" value="{{ $game['playing_time'] }}" required>
    <br></div>

    <div><label for="complexity">Complexité:</label>
        <input class="form-input bg-gray-200" type="text" name="complexity" value="{{ $game['complexity'] }}" required>
        <br></div>

    <div><label for="rating">Évaluation:</label>
        <input class="form-input bg-gray-200" type="number" name="rating" value="{{ $game['rating'] }}" required>
        <br></div>

    <div><label for="category">Catégorie:</label>
        <input class="form-input bg-gray-200" type="text" name="category" value="{{ $game['category'] }}" required>
        <br></div>

    <div><label for="published_date">Date de publication:</label>
        <input class="form-input bg-gray-200" type="date" name="published_date" value="{{ $game['published_date'] }}" required>
        <br></div>

    <label for="image">Nouvelle image:</label>
    <input type="file" name="image" value="{{ $game['image'] }}" required>
    <br>

    <input class="inline-block px-4 py-2 bg-red-400 text-white rounded-full font-bold hover:scale-90 transition duration-300" type="submit" value="Télécharger" name="Mettre à jour le jeu"></input>
    </form>

</form>
    </div>
</div>
<x-footer></x-footer>
</body>
</html>

