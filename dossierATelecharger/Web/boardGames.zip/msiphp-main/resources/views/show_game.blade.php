<!DOCTYPE html>
<html lang="en">
<head>
    <title>Détails du jeu</title>
    @vite(['resources/css/header.css', 'resources/css/footer.css'])
</head>
<body class="font-sans bg-[url('../images/fondTest.jpg')] bg-center bg-cover bg-no-repeat bg-fixed">
<x-header></x-header>
<div class="h-[60%] w-[50%] text-black bg-white rounded-2xl p-4 mt-[40px] ml-[25%]">
<h1 class="text-4xl text-center font-bold mb-[20px]">Détails du jeu</h1>
@if(isset($game))
    <ul class="flex flex-col ml-[2%] gap-2">
        @if(isset($game['image']))
            <li><img src="{{ URL::asset("storage/images/{$game["image"]}")}}" alt="Image du jeu"></li>
        @endif
        <li>Nom du jeu : {{ $game['name'] }}</li>

        <li>Description : {{ $game['description'] }}</li>
        <li>Prix : {{ $game['price'] }}</li>
        <li>Nombre de joueur : {{ $game['number_gamer'] }}</li>
        <li>Temps de jeu : {{ $game['playing_time'] }}</li>
        <li>Complexité : {{ $game['complexity'] }}</li>
        <li>Évaluation : {{ $game['rating'] }}</li>
        <li>Catégorie : {{ $game['category'] }}</li>
        <li>Date de publication : {{ $game['published_date'] }}</li>
    </ul>
@else
    <p>Le jeu n'a pas été trouvé.</p>
@endif
</div>
<x-footer></x-footer>
</body>
</html>
