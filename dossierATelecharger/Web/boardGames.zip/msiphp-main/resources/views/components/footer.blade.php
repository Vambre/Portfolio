@vite('resources/css/footer.css')
<footer class="flex border-2 border-white text-white bg-white mt-10 bottom-0 relative w-[100%]">
    <div class="flex flex-col gap-2 ml-auto mr-auto mb-20px">
        <h3 class="text-black">Informations</h3>
        <a class="text-black no-underline" href="">Contact</a>
        <a class="text-black no-underline" href="">A propos</a>
        <a class="text-black no-underline" href="">Conditions d'utilisation</a>
    </div>
    <div class="flex flex-col gap-2 ml-auto">
        <h3 class="text-black">Découvrir</h3>
        <a class="text-black no-underline" href="">Produits</a>
        <a class="text-black no-underline" href="">Services</a>
        <a class="text-black no-underline" href="">Secteurs d'activité</a>
        <a class="text-black no-underline" href="">Financement</a>
    </div>
    <div class="flex flex-col gap-2 ml-auto mr-auto">
        <h3 class="text-black">Reseaux sociaux</h3>
        <a class="text-black no-underline" href="">Instagram</a>
        <a class="text-black no-underline" href="">Facebook</a>
        <a class="text-black no-underline" href="">Linkedin</a>
        <a class="text-black no-underline" href="">X</a>
    </div>
</footer>
