@vite('resources/css/header.css')
<header class="flex gap-30px  text-white bg-transparent">
    <div class="gauche">
        <a href="{{route('index')}}"><img class="w-40 h-30" src="{{URL::asset('storage/images/pp.png')}}" alt="idk"> </a>
    </div>
    <div class="ml-[32%] mt-auto mb-auto">
        <h1 class="text-white font-bold text-5xl ml-30px">Toys Market</h1>
    </div>
    @guest
    <div class="ml-[20%] mt-auto mb-auto">
        <a class="inline-block px-4 py-2 bg-white text-black rounded-full font-bold hover:scale-90 transition duration-300" href="{{route('login')}}">Connexion</a>
        <a class="inline-block px-4 py-2 bg-white text-black rounded-full font-bold hover:scale-90 transition duration-300" href="{{route('register')}}">S'enregistrer</a>
    </div>
    @endguest
    @auth
        <div class="ml-[30%] mt-[35px]">
            {{Auth::user()->name}}
            <button class="inline-block px-4 py-2 bg-white text-black rounded-full font-bold hover:scale-90 transition duration-300"><a href="#" id="logout">Logout</a>
            </button>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                {{ csrf_field() }}
            </form>
        </div>
        <script>
            document.getElementById('logout').addEventListener("click", (event) => {
                document.getElementById('logout-form').submit();
            });
        </script>
    @endauth
</header>
