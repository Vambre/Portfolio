<div class="alert">
    <h3>{{$titre ?? 'A votre attention'}}</h3>
    <div>
       {{$slot}}
    </div>
</div>
