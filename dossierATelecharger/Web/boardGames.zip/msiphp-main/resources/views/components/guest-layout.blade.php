<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap">

    <!-- Scripts -->
    @vite(['resources/css/header.css', 'resources/css/footer.css' ])
</head>
<x-header></x-header>
<body class="font-sans bg-[url('../images/fondTest.jpg')] bg-center bg-cover bg-no-repeat bg-fixed">

    </div>
        @if($errors->isNotEmpty() )
            <x-information type="error" :message="$errors->get('msg')[0]"></x-information>
        @endif
    <div>
        {{ $slot }}
    </div>
    <x-footer></x-footer>


@auth
    <script>
        document.getElementById('logout').addEventListener("click", (event) => {
            document.getElementById('logout-form').submit();
        });
    </script>
@endauth
</body>
</html>
