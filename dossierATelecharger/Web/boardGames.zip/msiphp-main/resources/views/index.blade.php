<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des jeux</title>
    @vite('resources/css/index.css')
</head>
<body class="font-sans bg-[url('../images/fondTest.jpg')] bg-center bg-cover bg-no-repeat bg-fixed">

<x-header></x-header>

<h1 class="text-center text-white font-bold text-4xl">Liste des jeux</h1>

<button class="inline-block px-4 py-2 bg-white text-black rounded-full font-bold hover:scale-90 transition duration-300"><a href="{{ route('showAddGameForm') }}">Ajouter un jeu</a></button>

@if(count($jeux) > 0)
    <div class="flex flex-wrap ml-40 gap-8">

        @foreach($jeux as $jeu)
            <ul class="h-70 w-180 border-2 border-white text-gray-700 bg-white rounded-2xl p-4">
                    <img src="{{ URL::asset("storage/images/{$jeu["image"]}")}}" alt="Image du jeu" class="mb-4 w-[350px] h-[130px]"/>


                <h3 class="text-center text-black">Nom du jeu : {{ $jeu['name'] }}</h3>

                <div class=" flex items-stretch gap-12 ml-6">
                    <p>Nombre de joueur : {{ $jeu['number_gamer'] }}</p>
                    <p>Prix : {{ $jeu['price'] }}</p>
                </div>

                <div class="flex items-center gap-2 mt-9">
                    <form method="post" action="{{ route('deleteGame', ['id' => $jeu['id']]) }}" onsubmit="return confirm('Etes-vous sur de vouloir supprimer ?')">
                        @csrf @method('DELETE')
                        <button type="submit" class="inline-block px-4 py-2 bg-red-400 text-white rounded-full font-bold hover:scale-90 transition duration-300">Supprimer</button>
                    </form>

                    <button class="inline-block px-4 py-2 bg-red-400 text-white rounded-full font-bold hover:scale-90 transition duration-300">
                        <a href="{{ route('showGame', ['id' => $jeu['id']]) }}">Voir les détails</a>
                    </button>

                    <button class="inline-block px-4 py-2 bg-red-400 text-white rounded-full font-bold hover:scale-90 transition duration-300">
                        <a href="{{ route('editGameForm', ['id' => $jeu['id']]) }}">Modifier</a>
                    </button>
                </div>
            </ul>
        @endforeach

    </div>
@else
    <p class="text-white">Aucun jeu disponible pour le moment.</p>
@endif

<x-footer></x-footer>
</body>

</html>
