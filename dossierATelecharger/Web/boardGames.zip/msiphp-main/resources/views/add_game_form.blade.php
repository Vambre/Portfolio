<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @vite(['resources/css/header.css', 'resources/css/footer.css'])
    <title>Ajouter un jeu</title>
</head>
<body class="font-sans bg-[url('../images/fondTest.jpg')] bg-center bg-cover bg-no-repeat bg-fixed">
<x-header></x-header>
<div class="h-[60%] w-[50%] text-black bg-white rounded-2xl p-4 mt-[40px] ml-[25%]">
<h1 class="text-4xl text-center font-bold mb-[20px]">Ajouter un jeu</h1>

    <div class="flex ml-[25%}">
        <form  class="flex flex-col ml-[35%] gap-1" method="post" action="{{ route('addGame') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <label for="name">Nom du jeu :</label>
            <input class="form-input bg-gray-200" type="text" name="name" required>
            <br>

            <label for="description">Description :</label>
            <textarea class="form-input bg-gray-200" name="description" required></textarea>
            <br>


            <label for="price">Prix :</label>
            <input class="form-input bg-gray-200" type="number" name="price" required>
            <br>

            <label for="number_gamer">Nombre de joueur :</label>
            <input class="form-input bg-gray-200" type="number" name="number_gamer" required>
            <br>


            <label for="complexity">Complexite :</label>
            <input class="form-input bg-gray-200" type="number" name="complexity" required>
            <br>


            <label for="playing_time">Temps de jeu :</label>
            <input class="form-input bg-gray-200" type="number" name="playing_time" required>
            <br>

            <label for="image">Importer une image :</label>
            <input type="file" name="image"  required>
            <br>

            <input class="inline-block px-4 py-2 bg-red-400 text-white rounded-full font-bold hover:scale-90 transition duration-300" type="submit" value="Télécharger" name="Ajouter le jeu"></input>
        </form>
    </div>
</div>
<x-footer></x-footer>
</body>
</html>
