<x-guest-layout>

    <div class="h-[60%] w-[50%] text-black bg-white rounded-2xl p-4 mt-[40px] ml-[25%]">
        <div class="form-header">
            <h3 class="text-4xl text-center mb-[5px] font-bold">Connexion</h3>
            <p class="text-2xl text-center mb-[10px] font-bold">Accès au tableau de bord</p>
        </div>
        <form class="flex flex-col ml-[35%] gap-4" action="{{route('login')}}" method="post">
            @csrf

            <!--Email Input-->
            <div class="form-group">
                <input type="text" name="email" class="form-input bg-gray-200" placeholder="email@example.com">
            </div>
            <!--Password Input-->
            <div class="form-group">
                <input type="password" name="password" class="form-input bg-gray-200" placeholder="password">
            </div>
            <div class="form-group remember">
                <label class="text-black" for="remember">Remember</label>
                <input type="checkbox" name="remember" id="remember" class="form-input">
            </div>
            <!--Login Button-->
            <div class="form-group">
                <button class="inline-block px-4 py-2 bg-red-400 text-white rounded-full font-bold hover:scale-90 transition duration-300" type="submit">Login</button>
            </div>
            <div class="form-footer">
                <a class="inline-block px-4 py-2 bg-red-400 text-white rounded-full font-bold hover:scale-90 transition duration-300" href="{{route('register')}}">Créez un compte</a>
{{--                <div>
                    <a class="" href="{{route('password.request')}}">mot de passe oublié</a>
                </div>--}}

            </div>
        </form>
    </div><!--/.wrap-->


</x-guest-layout>
