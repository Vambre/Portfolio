<x-guest-layout>

    <div class="h-[60%] w-[50%] text-black bg-white rounded-2xl p-4 mt-[40px] ml-[25%]">
        <div class="form-header">
            <h3 class="text-4xl text-center mb-[5px] font-bold">Enregistrement</h3>
            <p class="text-2xl text-center mb-[10px] font-bold">Enregistrement pour l'accès à l'application</p>
        </div>
        <form class="flex flex-col ml-[35%] gap-4" action="{{route('register')}}" method="post">
            @csrf

            <!--Nom Input-->
            <div class="form-group">
                <input type="text" name="name" class="form-input bg-gray-200" placeholder="Prénom Nom">
            </div>
            <!--Email Input-->
            <div class="form-group">
                <input type="text" name="email" class="form-input bg-gray-200" placeholder="email@exemple.com">
            </div>
            <!--Password Input-->
            <div class="form-group">
                <input type="password" name="password" class="form-input bg-gray-200" placeholder="mot de passe">
            </div>
            <!--Confirm Password Input-->
            <div class="form-group">
                <input type="password" name="password_confirmation" class="form-input bg-gray-200" placeholder="Confirmez mot de passe">
            </div>
            <!--Login Button-->
            <div class="form-group">
                <button class="inline-block px-4 py-2 bg-red-400 text-white rounded-full font-bold hover:scale-90 transition duration-300" type="submit">Enregistrement</button>
            </div>
            <div class="form-footer">
                Vous avez déjà un compte ? <a class="inline-block px-4 py-2 bg-red-400 text-white rounded-full font-bold hover:scale-90 transition duration-300" href="{{route('login')}}">Connexion</a>
            </div>
        </form>
    </div><!--/.wrap-->

</x-guest-layout>
