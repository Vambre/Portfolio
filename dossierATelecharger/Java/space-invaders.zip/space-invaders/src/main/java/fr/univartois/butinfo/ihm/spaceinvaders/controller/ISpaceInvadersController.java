package fr.univartois.butinfo.ihm.spaceinvaders.controller;

import fr.univartois.butinfo.ihm.spaceinvaders.model.AbstractMovable;
import fr.univartois.butinfo.ihm.spaceinvaders.model.GameGrid;
import fr.univartois.butinfo.ihm.spaceinvaders.model.SpaceInvadersGame;
import javafx.beans.property.IntegerProperty;

public interface ISpaceInvadersController {

    /**
     * Associe au controleur la facade du jeu
     *
     * @param game
     */
    void setGame(SpaceInvadersGame game);

    /**
     * @param grid
     */
    void initGrid(GameGrid grid);

    /**
     * @param movable
     */
    void addMovable(AbstractMovable movable);

    /**
     * @param movable
     */
    void removeMovable(AbstractMovable movable);

    /**
     * @param message
     */
    void endGame(String message);

    void setScore(IntegerProperty score);

    void setHealth(IntegerProperty health);
}
