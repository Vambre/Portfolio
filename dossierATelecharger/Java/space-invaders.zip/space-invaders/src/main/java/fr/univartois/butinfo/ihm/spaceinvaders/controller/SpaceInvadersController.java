/**
 * Ce logiciel est distribué à des fins éducatives.
 * <p>
 * Il est fourni "tel quel", sans garantie d’aucune sorte, explicite
 * ou implicite, notamment sans garantie de qualité marchande, d’adéquation
 * à un usage particulier et d’absence de contrefaçon.
 * En aucun cas, les auteurs ou titulaires du droit d’auteur ne seront
 * responsables de tout dommage, réclamation ou autre responsabilité, que ce
 * soit dans le cadre d’un contrat, d’un délit ou autre, en provenance de,
 * consécutif à ou en relation avec le logiciel ou son utilisation, ou avec
 * d’autres éléments du logiciel.
 * <p>
 * (c) 2022-2023 Romain Wallon - Université d'Artois.
 * Tous droits réservés.
 */

package fr.univartois.butinfo.ihm.spaceinvaders.controller;

import java.net.URL;
import fr.univartois.butinfo.ihm.spaceinvaders.model.AbstractMovable;
import fr.univartois.butinfo.ihm.spaceinvaders.model.GameGrid;
import fr.univartois.butinfo.ihm.spaceinvaders.model.SpaceInvadersGame;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/**
 * La classe SpaceInvadersController illustre le fonctionnement du contrôleur associé à une vue.
 *
 * @author Romain Wallon
 * @version 0.1.0
 */
public class SpaceInvadersController implements ISpaceInvadersController {

    @FXML
    private GridPane gameGrid;

    @FXML
    private Label nbViesLabel;

    @FXML
    private Label scoreLabel;

    @FXML
    private Label etatLabel;

    private Label[][] cases;

    private Stage stage;

    private SpaceInvadersGame game;

    private boolean playing;

    @FXML
    public void initialize() {
        cases = new Label[20][20];
        for (int i = 0; i < cases.length; i++) {
            for (int j = 0; j < cases[i].length; j++) {
                cases[i][j] = new Label();
                cases[i][j].setPrefSize(30, 30);
                if (i < gameGrid.getRowCount() - 1) {
                    cases[i][j].setBackground(createBackground("back"));
                } else {
                    cases[i][j].setBackground(createBackground("land"));
                }
                gameGrid.add(cases[i][j], j, i);
            }
        }
        playing = true;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    private Background createBackground(String name) {
        URL urlImage = getClass().getResource("../view/images/" + name + ".png");
        BackgroundImage backgroundImage = new BackgroundImage(
                new Image(urlImage.toExternalForm(), 50, 50, true, false),
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.DEFAULT, BackgroundSize.DEFAULT);
        return new Background(backgroundImage);
    }

    private Node createGraphicFor(AbstractMovable movable) {
        HBox box = new HBox();
        box.setPrefHeight(50);
        box.setPrefWidth(50);
        box.setAlignment(Pos.CENTER);

        ImageView view = new ImageView(movable.getSprite());
        box.getChildren().add(view);

        return box;
    }


    @Override
    public void setGame(SpaceInvadersGame game) {
        this.game = game;
    }

    @Override
    public void initGrid(GameGrid grid) {
        for (int i = 0; i < grid.getHeight(); i++) {
            for (int j = 0; j < grid.getWidth(); j++) {
                final int row = i;
                final int column = j;
                ObjectProperty<AbstractMovable> property = grid.get(i, j).getMovableProperty();
                property.addListener(
                        (p, o, n) -> {
                            if (n != null) {
                                cases[row][column].setGraphic(createGraphicFor(property.getValue()));
                            } else {
                                cases[row][column].setGraphic(null);
                            }
                        }
                );
            }
        }

        stage.addEventFilter(KeyEvent.KEY_PRESSED, e -> {
                    if (playing) {
                        switch (e.getCode()) {
                            case LEFT -> game.moveLeft();
                            case RIGHT -> game.moveRight();
                        }
                    }
                }
        );
        stage.addEventFilter(KeyEvent.KEY_RELEASED, e -> {
            if (playing) {
                if (e.getCode() == KeyCode.SPACE) {
                    game.fireShot();
                }
            }
        });
    }

    @Override
    public void addMovable(AbstractMovable movable) {
        cases[movable.getRow()][movable.getColumn()].setGraphic(createGraphicFor(movable));
    }

    @Override
    public void removeMovable(AbstractMovable movable) {
        cases[movable.getRow()][movable.getColumn()].setGraphic(createGraphicFor(null));
    }

    @Override
    public void endGame(String message) {
        playing = false;
        etatLabel.setText(message);
    }

    @Override
    public void setScore(IntegerProperty score) {
        scoreLabel.textProperty().bind(score.asString());
    }

    @Override
    public void setHealth(IntegerProperty health) {
        nbViesLabel.textProperty().bind(health.asString());
    }
}
