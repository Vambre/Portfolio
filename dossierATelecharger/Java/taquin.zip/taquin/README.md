# Le *Taquin* avec *JavaFX*

Ce dépôt propose une implantation du jeu du *Taquin* utilisant *JavaFX*.
L'application proposée permet à deux joueurs de jouer sur le même interface,
chacun leur tour.
