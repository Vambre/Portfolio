package fr.univartois.butinfo.sae301;

public class temp {

}
